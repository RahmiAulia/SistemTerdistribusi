/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RAHMI200923;

/**
 *
 * @author Ideapad 5
 */
class PrintNameThread extends Thread {

    PrintNameThread(String name) {
        super(name);
    }

    public void run() {
        String name = getName();
        for (int i = 0; i < 100; i++) {
            System.out.print(name);
        }
    }
}

public class TestThread {

    public static void main(String args[]) {
        System.out.println("Mulai");
        PrintNameThread pnt1 = new PrintNameThread("A");
        PrintNameThread pnt2 = new PrintNameThread("B");
        PrintNameThread pnt3 = new PrintNameThread("C");
        PrintNameThread pnt4 = new PrintNameThread("D");

        // Memindahkan pemanggilan start() ke luar konstruktor
        pnt1.start();
        pnt2.start();
        pnt3.start();
        pnt4.start();

        try {
            // Menunggu hingga semua thread selesai
            pnt1.join();
            pnt2.join();
            pnt3.join();
            pnt4.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Selesai");
    }
}
