/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RAHMI130923;

import java.io.*;

/**
 *
 * @author Ideapad 5
 */
public class ReadFile {

    public static void main(String args[]) {
        System.out.println("Nama File?");
        String filename;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        try {
            filename = br.readLine();
            System.out.println("Now reading from " + filename + "...");

            try (FileInputStream fis = new FileInputStream(filename)) {
                int data;
                while ((data = fis.read()) != -1) {
                    System.out.print((char) data);
                    System.out.print("-");
                    System.out.print(data);
                }
            } catch (IOException ex) {
                System.out.println("Problem in reading from the file: " + ex.getMessage());
            }

        } catch (IOException ex) {
            System.out.println("Error reading input: " + ex.getMessage());
        }
    }
}
